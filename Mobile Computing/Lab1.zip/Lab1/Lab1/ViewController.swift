//
//  ViewController.swift
//  Lab1
//
//  Created by Samuel Randall on 2/13/19.
//  Copyright © 2019 Samuel Randall. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

