//
//  AnimalCell.swift
//  ms76497_assignment5
//
//  Created by Jorge Rivero III on 3/8/19.
//  Copyright © 2019 Slijepcevic, Milica. All rights reserved.
//

import UIKit

class AnimalCell: UICollectionViewCell {
    @IBOutlet weak var AnimalQuote: UILabel!
    @IBOutlet weak var AnimalImage: UIImageView!
    
}
