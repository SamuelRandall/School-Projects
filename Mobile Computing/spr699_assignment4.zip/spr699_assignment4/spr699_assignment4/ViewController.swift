//
//  ViewController.swift
//  spr699_assignment3
//
//  Created by Samuel Randall on 2/15/19.
//  Copyright © 2019 Samuel Randall. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    // MARK: Properties
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var listTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Handle the user's text input through delegate callbacks.
        nameTextField.delegate = self
        cityTextField.delegate = self
    }
    
    //MARK: UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    private func textFieldDidEndEditing(_ textField: UITextField) {
        listTextView.text += textField.text ?? "Default Text"
    }
    // MARK: Actions
    @IBAction func saveButton(_ sender: UIButton) {
        if nameTextField.text != "" && cityTextField.text != "" {
            listTextView.text += "Name: " + nameTextField.text! + ", City: " + cityTextField.text!
        }
        Å
    }
    
}

