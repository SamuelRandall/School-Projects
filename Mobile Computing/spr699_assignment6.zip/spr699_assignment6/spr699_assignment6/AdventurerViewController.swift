//
//  AdventurerViewController.swift
//  spr699_assignment6
//
//  Created by Samuel Randall on 4/2/19.
//  Copyright © 2019 Samuel Randall. All rights reserved.
//

import UIKit
import CoreData

class AdventurerViewController: UIViewController {
    
    var adv: NSManagedObject? = nil
    
    @IBOutlet weak var advImage: UIImageView!
    @IBOutlet weak var advName: UILabel!
    @IBOutlet weak var advClass: UILabel!
    @IBOutlet weak var advLevel: UILabel!
    @IBOutlet weak var advAttack: UILabel!
    @IBOutlet weak var advHP: UILabel!
    @IBOutlet weak var advQuest: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        advName.text = adv!.value(forKeyPath: "name") as? String
        advClass.text =  "Class: \(adv!.value(forKeyPath: "profession") as! String)"
        advLevel.text = "Level: \(adv!.value(forKeyPath: "level") as! String)"
        advHP.text = "\(adv!.value(forKeyPath: "currentHP") as! Int)/\(adv!.value(forKeyPath: "totalHP") as! Int)"
        advAttack.text =  "Attack: \(adv!.value(forKeyPath: "attack") as! Double)"
        advQuest.text = ""
        //   self.portrait.image = adv.value(forKeyPath: "portrait") as? UIImage
        
        adv!.setValue(adv!.value(forKeyPath: "totalHP") as! Int, forKey: "currentHP")


    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
