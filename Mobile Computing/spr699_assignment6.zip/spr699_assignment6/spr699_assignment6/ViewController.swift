//
//  ViewController.swift
//  spr699_assignment6
//
//  Created by Samuel Randall on 3/13/19.
//  Copyright © 2019 Samuel Randall. All rights reserved.
//

import UIKit

<<<<<<< HEAD
=======

>>>>>>> 3fbf443440446c40e9079a4e64fd62c6acca881e
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
<<<<<<< HEAD


=======
>>>>>>> 3fbf443440446c40e9079a4e64fd62c6acca881e
}

